const express = require('express');
const app = express();
const PORT = 3000;


app.use((req, res, next) => {
  console.log(`${req.method} request for ${req.url}`);
  next();
});


app.get('/', (req, res) => {
  res.send('<h1>Welcome to my Express Server</h1>');
});


app.get('/about', (req, res) => {
  res.send('<h1>About Page</h1><p>This is a simple Express.js app for Week 4 assignment.</p>');
});


app.use((req, res) => {
  res.status(404).send('<h1>404 - Page Not Found</h1>');
});


app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
